import cv2
import numpy as np

def detect_table(gray):
    """Heuristic table detector: looks for intersecting horizontal and vertical rules."""
    binary = cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY_INV, 31, 15
    )
    h, w = binary.shape
    horizontal_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (max(20, w // 30), 1))
    vertical_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, max(20, h // 30)))
    horizontal = cv2.morphologyEx(binary, cv2.MORPH_OPEN, horizontal_kernel)
    vertical = cv2.morphologyEx(binary, cv2.MORPH_OPEN, vertical_kernel)
    h_count = cv2.countNonZero(horizontal)
    v_count = cv2.countNonZero(vertical)
    # A table is more likely when both horizontal and vertical rules are present.
    detected = h_count > w * 0.35 and v_count > h * 0.25
    return detected, horizontal, vertical

def line_positions(mask, axis):
    projection = (mask > 0).sum(axis=axis)
    threshold = max(5, int(mask.shape[1-axis] * 0.25))
    indices = np.where(projection >= threshold)[0]
    if len(indices) == 0:
        return []
    groups = []
    start = prev = int(indices[0])
    for value in indices[1:]:
        value = int(value)
        if value > prev + 2:
            groups.append((start + prev) // 2)
            start = value
        prev = value
    groups.append((start + prev) // 2)
    return groups
