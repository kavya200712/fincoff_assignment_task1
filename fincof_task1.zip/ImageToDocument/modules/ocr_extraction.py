import easyocr

_reader = None

def get_reader():
    global _reader
    if _reader is None:
        _reader = easyocr.Reader(["en"], gpu=False)
    return _reader

def extract_words(gray):
    reader = get_reader()
    return reader.readtext(gray, detail=1, paragraph=False)
