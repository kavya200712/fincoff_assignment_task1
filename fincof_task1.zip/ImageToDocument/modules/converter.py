import io
import os
import cv2
import numpy as np
import pandas as pd
from docx import Document
from docx.shared import Inches, Pt
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from .preprocessing import preprocess
from .ocr_extraction import extract_words
from .content_detection import detect_table, line_positions

def _center(box):
    pts = np.array(box, dtype=float)
    return float(pts[:, 0].mean()), float(pts[:, 1].mean())

def _make_docx(text):
    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(0.7)
    section.bottom_margin = Inches(0.7)
    for line in text.splitlines():
        line = line.strip()
        if not line:
            doc.add_paragraph()
        elif line.isupper() and len(line) < 80:
            doc.add_heading(line.title(), level=2)
        else:
            doc.add_paragraph(line)
    output = io.BytesIO()
    doc.save(output)
    return output.getvalue()

def _make_xlsx(df):
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, header=False, sheet_name="Extracted Table")
        ws = writer.sheets["Extracted Table"]
        for cell in ws[1]:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="4472C4")
        for row in ws.iter_rows():
            for cell in row:
                cell.alignment = Alignment(vertical="center", wrap_text=True)
                cell.border = Border(bottom=Side(style="thin", color="D9E1F2"))
        for col in ws.columns:
            letter = col[0].column_letter
            max_len = max((len(str(c.value or "")) for c in col), default=10)
            ws.column_dimensions[letter].width = min(max(max_len + 2, 12), 40)
    return output.getvalue()

def _extract_table(words, horizontal, vertical, shape):
    h, w = shape
    ys = line_positions(horizontal, axis=1)
    xs = line_positions(vertical, axis=0)
    # If borders are incomplete, fall back to approximate row/column clustering.
    if len(ys) < 2 or len(xs) < 2:
        return None
    rows, cols = len(ys) - 1, len(xs) - 1
    if rows < 1 or cols < 2 or rows > 100 or cols > 30:
        return None
    cells = [["" for _ in range(cols)] for _ in range(rows)]
    for box, text, confidence in words:
        cx, cy = _center(box)
        col = next((i for i in range(cols) if xs[i] <= cx < xs[i+1]), None)
        row = next((i for i in range(rows) if ys[i] <= cy < ys[i+1]), None)
        if row is not None and col is not None:
            cells[row][col] = (cells[row][col] + " " + text).strip()
    # Reject a grid that captured almost no recognised text.
    nonempty = sum(bool(x.strip()) for row in cells for x in row)
    if nonempty < 2:
        return None
    return pd.DataFrame(cells)

def _words_to_text(words):
    items = []
    for box, text, confidence in words:
        cx, cy = _center(box)
        items.append((cy, cx, text))
    items.sort(key=lambda x: (x[0], x[1]))
    if not items:
        return ""
    # Group detections on approximately the same text line.
    lines = []
    current = []
    current_y = None
    for y, x, text in items:
        if current_y is None or abs(y - current_y) <= 18:
            current.append((x, text))
            current_y = y if current_y is None else (current_y * 0.6 + y * 0.4)
        else:
            lines.append(" ".join(t for _, t in sorted(current)))
            current = [(x, text)]
            current_y = y
    if current:
        lines.append(" ".join(t for _, t in sorted(current)))
    return "\n".join(lines)

def convert_image(pil_image, output_choice="Auto-detect"):
    gray = preprocess(pil_image)
    words = extract_words(gray)
    is_table, horizontal, vertical = detect_table(gray)

    df = _extract_table(words, horizontal, vertical, gray.shape) if is_table else None
    force_excel = output_choice.startswith("Excel")
    force_word = output_choice.startswith("Word")

    if df is not None and not force_word:
        content = _make_xlsx(df)
        return {
            "kind": "Table", "message": "A grid-like table was detected. Review the cells for OCR errors.",
            "dataframe": df, "bytes": content, "filename": "extracted_table.xlsx",
            "mime": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        }

    if force_excel:
        # Fallback: put OCR lines into a single-column spreadsheet if no grid is detected.
        text = _words_to_text(words)
        rows = [[line] for line in text.splitlines()]
        df = pd.DataFrame(rows)
        content = _make_xlsx(df)
        return {
            "kind": "Text converted to spreadsheet", "message": "No clear table grid was found; OCR lines were placed in one Excel column.",
            "dataframe": df, "bytes": content, "filename": "extracted_content.xlsx",
            "mime": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        }

    text = _words_to_text(words)
    if not text.strip():
        raise ValueError("No text was recognised. Try a sharper, higher-resolution image.")
    content = _make_docx(text)
    return {
        "kind": "Paragraph / text", "message": "Text was extracted in reading order. Review the text before using it.",
        "text": text, "bytes": content, "filename": "extracted_text.docx",
        "mime": "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    }
