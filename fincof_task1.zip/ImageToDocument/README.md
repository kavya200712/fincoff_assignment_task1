# Image to Editable Word / Excel Converter

A Python + Streamlit application that reads text from an image and creates an editable `.docx` or `.xlsx` file.

## Features
- Upload PNG, JPG, JPEG, BMP or TIFF images.
- Image preprocessing with OpenCV.
- OCR with EasyOCR (English model).
- Heuristic detection of bordered tables.
- Editable Word output using `python-docx`.
- Editable Excel output using `pandas` and `openpyxl`.
- Preview extracted text/table and correct paragraph OCR text before downloading.
- Manual output-format override.

## Setup

Python 3.10 or 3.11 is recommended.

### Windows
Open PowerShell in this folder and run:

```powershell
py -3.11 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

If PowerShell blocks activation, run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.venv\Scripts\Activate.ps1
```

### Linux / macOS

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

The application opens in your browser, usually at `http://localhost:8501`.

## Important notes
- EasyOCR downloads its pretrained model the first time it runs; internet access is needed for that initial download.
- This starter version uses English OCR.
- Automatic table detection is strongest on clear tables with visible horizontal and vertical borders. Borderless tables and complex merged cells may need a stronger table-structure model or manual correction.
- OCR is not guaranteed to be perfect. Always verify names, dates, decimal points and financial figures before relying on the output.
- Mixed paragraph-and-table page support is basic in this first version: Auto-detect chooses Excel when it finds a clear bordered table; otherwise it chooses Word.
- For confidential documents, process locally and do not upload them to an untrusted hosted service.

## Project structure

```text
ImageToDocument/
├── app.py
├── modules/
│   ├── __init__.py
│   ├── preprocessing.py
│   ├── ocr_extraction.py
│   ├── content_detection.py
│   └── converter.py
├── outputs/
│   ├── word/
│   └── excel/
├── samples/
├── requirements.txt
└── README.md
```
