import os
import streamlit as st
from PIL import Image
from modules.converter import convert_image

st.set_page_config(page_title="Image to Editable Document", page_icon="📄", layout="wide")
st.title("Image to Editable Word / Excel Converter")
st.write("Upload an image. The application extracts its content and creates an editable Word or Excel file.")

uploaded = st.file_uploader("Upload an image", type=["png", "jpg", "jpeg", "bmp", "tiff"])
if uploaded:
    image = Image.open(uploaded).convert("RGB")
    st.image(image, caption="Uploaded image", use_container_width=True)

    output_choice = st.radio(
        "Output format",
        ["Auto-detect", "Word (.docx)", "Excel (.xlsx)"],
        horizontal=True,
        help="Auto-detect chooses Excel when a table is detected; otherwise it creates Word."
    )

    if st.button("Extract content and generate file", type="primary"):
        with st.spinner("Processing image. The first run may take longer while OCR models load..."):
            try:
                result = convert_image(image, output_choice)
                st.session_state["conversion_result"] = result
            except Exception as e:
                st.error(f"Could not process this image: {e}")
                st.info("Check the installation instructions in README.md. EasyOCR may need to download its model the first time.")

if "conversion_result" in st.session_state:
    result = st.session_state["conversion_result"]
    st.success(f"Detected content: {result['kind']}")
    st.caption(result["message"])

    if result["kind"] == "Table":
        st.subheader("Extracted table (editable preview)")
        st.dataframe(result["dataframe"], use_container_width=True)
    else:
        st.subheader("Extracted text (editable preview)")
        edited = st.text_area("You can correct OCR mistakes before generating the Word file:",
                              result["text"], height=260)
        result["text"] = edited

    st.download_button(
        label=f"Download {result['filename']}",
        data=result["bytes"],
        file_name=result["filename"],
        mime=result["mime"],
        type="primary"
    )

st.divider()
st.caption("For best results, use a clear, straight, well-lit image. OCR output should be reviewed before use.")
